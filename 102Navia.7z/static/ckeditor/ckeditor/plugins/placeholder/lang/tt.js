﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","tt",{title:"Тутырма үзлекләре",toolbar:"Тутырма",name:"Тутырма исеме",invalidName:"Тутырма буш булмаска тиеш һәм эчендә алдагы символлар булмаска тиеш: [, ], <, >",pathName:"тутырма"});